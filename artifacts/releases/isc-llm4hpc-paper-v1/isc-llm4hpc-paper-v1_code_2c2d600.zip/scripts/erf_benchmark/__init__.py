"""ERF benchmark script package."""

